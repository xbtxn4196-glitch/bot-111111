import os
from pathlib import Path

from dotenv import load_dotenv

# Render-এ Secret File / Environment Variable থেকে .env লোড হবে
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent


def _get_int(name: str, default: int = 0) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _get_admin_ids() -> set[int]:
    raw = os.getenv("ADMIN_IDS", "")
    ids = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if part.lstrip("-").isdigit():
            ids.add(int(part))
    return ids


BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()

# চ্যানেল আইডি
SOURCE_CHANNEL = _get_int("SOURCE_CHANNEL", -1002279362776)
DEST_CHANNEL = _get_int("DEST_CHANNEL", -1004308076789)

# অ্যাডমিন (একাধিক হলে কমা দিয়ে)
ADMIN_IDS = _get_admin_ids()

# ডাটাবেজ (Render-এ /data ডিস্ক মাউন্ট করা থাকলে সেখানেই থাকবে)
DB_PATH = os.getenv("DB_PATH", str(BASE_DIR / "data" / "bot.db"))

# ডিফল্ট ভাষা
DEFAULT_LANG = os.getenv("DEFAULT_LANG", "bn").strip().lower()

# টাইমজোন
TIMEZONE = os.getenv("TZ", "Asia/Dhaka")

# ভিডিওর নিচের ক্যাপশনে যা যাবে
VIDEO_CAPTION_TEMPLATE = os.getenv("VIDEO_CAPTION", "🎬 <b>{title}</b>\n🏆 {team}\n📅 {year}")

# ফাইল/লিস্টিং সাইজ
PAGE_MATCHES = 6
PAGE_TEAMS = 10
PAGE_USERS = 8
PAGE_ADMIN_MATCHES = 8
SEARCH_LIMIT = 100

MAX_BROADCAST_PER_SECOND = 25

# বট চালু হওয়ার সময় — এর আগের পুরোনো চ্যানেল পোস্ট ইগনোর হবে
from datetime import datetime, timezone  # noqa: E402

STARTED_AT = datetime.now(timezone.utc)
