"""শেয়ার্ড হেল্পার — ভাষা, অ্যাডমিন চেক, প্যানেল পাঠানো।"""

import config
from keyboards import admin_kb
from locales import LANGUAGES, t


async def get_lang(db, user_id: int) -> str:
    row = await db.get_user(user_id)
    if row and row["lang"]:
        return row["lang"]
    return config.DEFAULT_LANG if config.DEFAULT_LANG in LANGUAGES else "bn"


async def is_admin(db, user_id: int) -> bool:
    if user_id in config.ADMIN_IDS:
        return True
    owner = await db.get_setting("owner_id")
    return bool(owner and str(user_id) == owner)


async def admin_ids(db) -> list[int]:
    ids = set(config.ADMIN_IDS)
    owner = await db.get_setting("owner_id")
    if owner and owner.lstrip("-").isdigit():
        ids.add(int(owner))
    return sorted(ids)


async def notify_admins(db, bot, text: str, reply_markup=None) -> None:
    """সব অ্যাডমিনকে নোটিফিকেশন (প্রত্যেকের নিজের ভাষায় নয় — একই টেক্সট)।"""
    for uid in await admin_ids(db):
        try:
            await bot.send_message(uid, text, reply_markup=reply_markup)
        except Exception:
            continue


async def send_admin_panel(message, db, lang: str, edit: bool = False) -> None:
    text = t(lang, "ap_title")
    kb = admin_kb(lang)
    if edit:
        await message.edit_text(text, reply_markup=kb)
    else:
        await message.answer(text, reply_markup=kb)
