"""সব কীবোর্ড — reply menu ও inline বাটন।"""

from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardMarkup,
)

from locales import LANGUAGES, t
from utils import match_ref, team_ref

# locale key → action (মেনু প্রসেসিং এক জায়গায়)
MENU_KEYS = {
    "menu_search": "search",
    "menu_popular": "popular",
    "menu_latest": "latest",
    "menu_teams": "teams",
    "menu_lang": "lang",
    "menu_help": "help",
    "menu_admin": "admin",
    "menu_home": "menu",
}


def main_menu_kb(lang: str, is_admin: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=t(lang, "menu_search")), KeyboardButton(text=t(lang, "menu_popular"))],
        [KeyboardButton(text=t(lang, "menu_latest")), KeyboardButton(text=t(lang, "menu_teams"))],
        [KeyboardButton(text=t(lang, "menu_lang")), KeyboardButton(text=t(lang, "menu_help"))],
    ]
    if is_admin:
        rows.append([KeyboardButton(text=t(lang, "menu_admin"))])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True, is_persistent=True)


def lang_kb() -> InlineKeyboardMarkup:
    rows = []
    row = []
    for code, name in LANGUAGES.items():
        row.append(InlineKeyboardButton(text=name, callback_data=f"lang:{code}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ------------------------------------------------------------------ listings
def _nav_row(lang: str, page: int, total_pages: int, kind: str, ref: str) -> list:
    if total_pages <= 1:
        return []
    row = []
    if page > 1:
        row.append(
            InlineKeyboardButton(text=t(lang, "btn_prev"), callback_data=f"pg:{kind}:{ref}:{page - 1}")
        )
    row.append(
        InlineKeyboardButton(text=f"· {page}/{total_pages} ·", callback_data="noop")
    )
    if page < total_pages:
        row.append(
            InlineKeyboardButton(text=t(lang, "btn_next"), callback_data=f"pg:{kind}:{ref}:{page + 1}")
        )
    return row


def list_markup(
    lang: str,
    item_buttons: list[tuple[str, str]],
    page: int,
    total_pages: int,
    kind: str,
    ref: str = "",
    back_cb: str = "home",
) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text=text, callback_data=cb)] for text, cb in item_buttons]
    nav = _nav_row(lang, page, total_pages, kind, ref)
    if nav:
        rows.append(nav)
    if back_cb:
        rows.append([InlineKeyboardButton(text=t(lang, "btn_back"), callback_data=back_cb)])
    return InlineKeyboardMarkup(inline_keyboard=rows or [[InlineKeyboardButton(text="•", callback_data="noop")]])


def match_buttons(lang: str, rows, page: int, total: int, page_size: int, kind: str, ref: str, back_cb: str = "home"):
    buttons = []
    for m in rows:
        title = (m["title"] or "").strip()
        if len(title) > 34:
            title = title[:31] + "…"
        label = f"🎬 {m['team']}" + (f" — {title}" if title else "")
        buttons.append((label[:64], f"v:{match_ref(m['id'])}"))
    total_pages = max(1, (total + page_size - 1) // page_size)
    return list_markup(lang, buttons, page, total_pages, kind, ref, back_cb)


def team_buttons(lang: str, teams, page: int, total: int, page_size: int, back_cb: str = "home"):
    buttons = []
    for row in teams:
        buttons.append((f"🏆 {row['team']} ({row['total']})", f"tm:{team_ref(row['team_key'])}:0"))
    total_pages = max(1, (total + page_size - 1) // page_size)
    return list_markup(lang, buttons, page, total_pages, "tl", "", back_cb)


# ------------------------------------------------------------------ ad gate
def ad_kb(lang: str, match_id: int, url: str = "", btn_text: str = "") -> InlineKeyboardMarkup:
    rows = []
    if url:
        rows.append(
            [
                InlineKeyboardButton(
                    text=btn_text or t(lang, "ad_btn_open"),
                    url=url,
                )
            ]
        )
    rows.append(
        [
            InlineKeyboardButton(
                text=t(lang, "ad_btn_continue"),
                callback_data=f"vx:{match_ref(match_id)}",
            )
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ------------------------------------------------------------------ admin
def admin_kb(lang: str) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=t(lang, "ap_stats"), callback_data="a:stats"),
            InlineKeyboardButton(text=t(lang, "ap_users"), callback_data="a:users:0"),
        ],
        [
            InlineKeyboardButton(text=t(lang, "ap_ad"), callback_data="a:ad"),
            InlineKeyboardButton(text=t(lang, "ap_matches"), callback_data="a:matches:0"),
        ],
        [
            InlineKeyboardButton(text=t(lang, "ap_manual"), callback_data="a:manual"),
            InlineKeyboardButton(text=t(lang, "ap_broadcast"), callback_data="a:bc"),
        ],
        [InlineKeyboardButton(text=t(lang, "ap_sync"), callback_data="a:sync")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def ad_panel_kb(lang: str, ad_on: bool, has_text: bool) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=t(lang, "ad_set_text"), callback_data="a:ad:text"),
            InlineKeyboardButton(text=t(lang, "ad_set_btn"), callback_data="a:ad:btn"),
        ],
        [InlineKeyboardButton(text=t(lang, "ad_set_url"), callback_data="a:ad:url")],
    ]
    toggle_text = t(lang, "ad_toggle_off") if ad_on else t(lang, "ad_toggle_on")
    rows.append([InlineKeyboardButton(text=toggle_text, callback_data="a:ad:toggle")])
    extra = []
    if has_text:
        extra.append(InlineKeyboardButton(text=t(lang, "ad_preview"), callback_data="a:ad:preview"))
        extra.append(InlineKeyboardButton(text=t(lang, "ad_clear"), callback_data="a:ad:clear"))
    if extra:
        rows.append(extra)
    rows.append([InlineKeyboardButton(text=t(lang, "btn_back"), callback_data="a:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def admin_matches_kb(lang: str, rows_matches, page: int, total: int, page_size: int) -> InlineKeyboardMarkup:
    buttons = []
    for m in rows_matches:
        title = (m["title"] or "").strip()
        if len(title) > 26:
            title = title[:23] + "…"
        buttons.append((f"🎬 #{m['id']} {m['team']} — {title}"[:64], f"am:{m['id']}:{page}"))
    total_pages = max(1, (total + page_size - 1) // page_size)
    return list_markup(lang, buttons, page, total_pages, "mt", "", "a:home")


def match_admin_kb(lang: str, match_id: int, page: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=t(lang, "me_team_btn"), callback_data=f"emt:{match_id}:{page}"),
            InlineKeyboardButton(text=t(lang, "me_title_btn"), callback_data=f"emz:{match_id}:{page}"),
        ],
        [InlineKeyboardButton(text=t(lang, "send_me"), callback_data=f"amd:{match_id}")],
        [
            InlineKeyboardButton(text=t(lang, "me_delete_btn"), callback_data=f"adm:{match_id}:{page}"),
            InlineKeyboardButton(text=t(lang, "btn_back"), callback_data=f"a:matches:{page}"),
        ],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def delete_confirm_kb(lang: str, match_id: int, page: int) -> InlineKeyboardMarkup:
    rows = [
        [
            InlineKeyboardButton(text=t(lang, "delete_yes"), callback_data=f"admy:{match_id}:{page}"),
            InlineKeyboardButton(text=t(lang, "delete_no"), callback_data=f"am:{match_id}:{page}"),
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def sync_kb(lang: str, auto_on: bool) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=t(lang, "sync_toggle"), callback_data="a:sync:toggle")],
        [InlineKeyboardButton(text=t(lang, "sync_test"), callback_data="a:sync:test")],
        [InlineKeyboardButton(text=t(lang, "btn_back"), callback_data="a:home")],
    ]
    return InlineKeyboardMarkup(inline_keyboard=rows)


def users_kb(lang: str, page: int, total_pages: int) -> InlineKeyboardMarkup:
    rows = []
    if total_pages > 1:
        nav = []
        if page > 1:
            nav.append(InlineKeyboardButton(text=t(lang, "btn_prev"), callback_data=f"a:users:{page - 1}"))
        nav.append(InlineKeyboardButton(text=f"· {page}/{total_pages} ·", callback_data="noop"))
        if page < total_pages:
            nav.append(InlineKeyboardButton(text=t(lang, "btn_next"), callback_data=f"a:users:{page + 1}"))
        rows.append(nav)
    rows.append([InlineKeyboardButton(text=t(lang, "btn_back"), callback_data="a:home")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def back_kb(lang: str, cb: str = "a:home") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t(lang, "btn_back"), callback_data=cb)]]
    )


def cancel_kb(lang: str, cb: str = "a:home") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text=t(lang, "btn_cancel"), callback_data=cb)]]
    )


def ad_preview_kb(lang: str, url: str = "", btn_text: str = "") -> InlineKeyboardMarkup:
    rows = []
    if url:
        rows.append([InlineKeyboardButton(text=btn_text or t(lang, "ad_btn_open"), url=url)])
    rows.append([InlineKeyboardButton(text=t(lang, "btn_back"), callback_data="a:ad")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
