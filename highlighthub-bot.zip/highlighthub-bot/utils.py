"""হেল্পার ফাংশন — নাম নরমালাইজ, ফাজি সার্চ, ক্যাপশন পার্স, মিডিয়া এক্সট্রাকশন।"""

import difflib
import hashlib
import re
import unicodedata
from datetime import datetime, timezone

# ------------------------------------------------ লেবেল ম্যাপ (সব ভাষার বাটন)
# locale key -> handler action
LABEL_ACTIONS = {
    # Bangla
    "🔍 সার্চ": "search",
    "🔥 জনপ্রিয়": "popular",
    "🆕 লেটেস্ট": "latest",
    "📂 টিম লিস্ট": "teams",
    "🌐 ভাষা": "lang",
    "ℹ️ সাহায্য": "help",
    "🛠 অ্যাডমিন প্যানেল": "admin",
    "🏠 মেনু": "menu",
    # English
    "🔍 Search": "search",
    "🔥 Popular": "popular",
    "🆕 Latest": "latest",
    "📂 Teams": "teams",
    "🌐 Language": "lang",
    "ℹ️ Help": "help",
    "🛠 Admin Panel": "admin",
    "🏠 Menu": "menu",
    # Hindi
    "🔍 सर्च": "search",
    "🔥 लोकप्रिय": "popular",
    "🆕 नवीनतम": "latest",
    "📂 टीम लिस्ट": "teams",
    "🌐 भाषा": "lang",
    "ℹ️ मदद": "help",
    "🛠 एडमिन पैनल": "admin",
    "🏠 मेनू": "menu",
    # Urdu
    "🔍 تلاش": "search",
    "🔥 مقبول": "popular",
    "🆕 تازہ ترین": "latest",
    "📂 ٹیمیں": "teams",
    "🌐 زبان": "lang",
    "ℹ️ مدد": "help",
    "🛠 ایڈمن پینل": "admin",
    "🏠 مینو": "menu",
    # Arabic
    "🔍 بحث": "search",
    "🔥 الأكثر شعبية": "popular",
    "🆕 الأحدث": "latest",
    "📂 الفرق": "teams",
    "🌐 اللغة": "lang",
    "ℹ️ مساعدة": "help",
    "🛠 لوحة الإدارة": "admin",
    "🏠 القائمة": "menu",
}

_URL_RE = re.compile(r"(https?://\S+|www\.\S+|t\.me/\S+|\S+@\S+\.\S+|@\w+)", re.IGNORECASE)
_HASHTAG_RE = re.compile(r"#([\w\u0600-\u06FF\u0900-\u097F\u0980-\u09FF]+)", re.UNICODE)
_YEAR_RE = re.compile(r"\b(19[5-9]\d|20[0-2]\d)\b")


# ------------------------------------------------------------------ normalize
def norm(text: str) -> str:
    """সার্চের জন্য টেক্সট নরমালাইজ (case, যুক্তি/চিহ্ন সব বাদ)।"""
    if not text:
        return ""
    text = unicodedata.normalize("NFKC", str(text)).casefold()
    text = text.replace("_", " ")
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip()


def compact(text: str) -> str:
    return norm(text).replace(" ", "")


def match_ref(match_id: int) -> str:
    """রিভার্জিবল শর্ট রেফ: 123-abcdef (কলব্যাক ডেটা ৬৪ বাইটের মধ্যে)।"""
    sig = hashlib.md5(f"m{match_id}".encode()).hexdigest()[:6]
    return f"{match_id}-{sig}"


def match_id_from_ref(ref: str) -> int:
    try:
        return int(str(ref).split("-")[0])
    except (ValueError, TypeError):
        return 0


def team_ref(team_key: str) -> str:
    return hashlib.md5(("t" + team_key).encode()).hexdigest()[:10]


async def load_ad(db) -> dict | None:
    """অ্যাড চালু থাকলে অ্যাডের ডেটা, নাহলে None।"""
    s = await db.get_settings("ad_")
    text = (s.get("ad_text") or "").strip()
    if s.get("ad_active") == "1" and text:
        return {
            "text": text,
            "btn": (s.get("ad_btn") or "").strip(),
            "url": (s.get("ad_url") or "").strip(),
        }
    return None


async def resolve_team_ref(db, ref: str) -> str | None:
    """team_ref থেকে team_key বের করে (ক্যাশ + DB ফলব্যাক)।"""
    if ref in _TEAM_REF_CACHE:
        return _TEAM_REF_CACHE[ref]
    for row in await db.get_teams():
        _TEAM_REF_CACHE[team_ref(row["team_key"])] = row["team_key"]
    return _TEAM_REF_CACHE.get(ref)


_TEAM_REF_CACHE: dict[str, str] = {}


def split_camel(text: str) -> str:
    """RealMadrid -> Real Madrid"""
    return re.sub(r"(?<=[a-z])(?=[A-Z])", " ", text)


# ------------------------------------------------------------------ fuzzy
def _field_score(query: str, query_compact: str, field_text: str) -> float:
    if not query or not field_text:
        return 0.0
    field = norm(field_text)
    if not field:
        return 0.0
    if query == field:
        return 1.0
    if query in field or (query_compact and query_compact in field.replace(" ", "")):
        return 0.93
    qtokens = [t for t in query.split() if len(t) >= 3]
    ftokens = [t for t in field.split() if len(t) >= 3]
    if qtokens and all(t in field for t in qtokens):
        return 0.90
    best = difflib.SequenceMatcher(None, query, field).ratio()
    for q in qtokens or query.split():
        for f in ftokens or field.split():
            r = difflib.SequenceMatcher(None, q, f).ratio()
            if r > best:
                best = r
    return best * 0.97


def score_match(query: str, row) -> float:
    """একটা ম্যাচ কতটা query-র সাথে মিলে (0..1)।"""
    q = norm(query)
    if not q:
        return 0.0
    qc = q.replace(" ", "")
    best = 0.0
    fields = [row["team"], row["title"], row["team_key"]]
    tags = row["tags"] or ""
    if tags:
        for tag in tags.split(","):
            tag = tag.strip()
            if tag:
                fields.append(tag)
                fields.append(split_camel(tag))
    for f in fields:
        best = max(best, _field_score(q, qc, f))
        if best >= 1.0:
            break
    # বছরও মিললে একটু বুস্ট
    year = (row["year"] or "").strip()
    if year and year in q.split():
        best += 0.05
    return min(best, 1.0)


def search_matches(rows: list, query: str, threshold: float = 0.55, limit: int = 100) -> list:
    scored = []
    for row in rows:
        s = score_match(query, row)
        if s >= threshold:
            scored.append((s, row["views"] or 0, row))
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return [r for _, _, r in scored[:limit]]


def suggest_teams(teams: list, query: str, limit: int = 5) -> list:
    q = norm(query)
    if not q:
        return []
    scored = []
    for row in teams:
        s = _field_score(q, q.replace(" ", ""), row["team"])
        if s >= 0.45 and s < 1.0:
            scored.append((s, row["team"]))
    scored.sort(reverse=True)
    out, seen = [], set()
    for _, name in scored:
        key = norm(name)
        if key not in seen:
            seen.add(key)
            out.append(name)
        if len(out) >= limit:
            break
    return out


# ------------------------------------------------------------------ caption
def parse_caption(caption: str | None) -> dict:
    """চ্যানেলের ক্যাপশন থেকে টিম, টাইটেল, সাল, হ্যাশট্যাগ বের করে।"""
    raw = (caption or "").strip()
    hashtags = [h for h in _HASHTAG_RE.findall(raw)]
    text = _URL_RE.sub(" ", raw)
    text = re.sub(r"#\S+", " ", text)
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    title = lines[0] if lines else ""
    if len(title) < 12 and len(lines) > 1:
        title = f"{title} {lines[1]}".strip()
    title = re.sub(r"\s{2,}", " ", title).strip(" -–|:•")
    if len(title) > 180:
        title = title[:177].rsplit(" ", 1)[0] + "…"

    year_match = _YEAR_RE.search(raw)
    year = year_match.group(1) if year_match else ""

    team = ""
    if hashtags:
        team = split_camel(hashtags[0]).replace("_", " ").strip()
    if not team:
        if "|" in title:
            team = title.split("|")[0].strip()
        else:
            vs = re.split(r"\s+vs\.?\s+|\s+v\s+", title, maxsplit=1, flags=re.IGNORECASE)
            team = vs[0].strip() if len(vs) == 2 else " ".join(title.split()[:3])
    team = re.sub(r"\s{2,}", " ", team).strip(" -–|:•")
    if len(team) > 48:
        team = team[:48]

    if not team:
        team = "Highlights"
    if not title:
        title = team

    return {
        "team": team,
        "title": title,
        "year": year,
        "tags": ",".join(dict.fromkeys(hashtags)),
    }


# ------------------------------------------------------------------ media
def extract_media(message) -> tuple[str, str, str]:
    """(media_type, file_id, file_unique_id) রিটার্ন করে।"""
    if message.video:
        vid = message.video
        return "video", vid.file_id, vid.file_unique_id
    if message.animation:
        anim = message.animation
        return "animation", anim.file_id, anim.file_unique_id
    if message.document:
        doc = message.document
        mime = (doc.mime_type or "").lower()
        if mime.startswith("video") or mime in ("application/mp4", "video/mp4"):
            return "document", doc.file_id, doc.file_unique_id
    return "", "", ""


def message_text_or_caption(message) -> str:
    return message.caption or message.text or ""


# ------------------------------------------------------------------ misc
def fmt_date(iso: str, tz=None) -> str:
    if not iso:
        return "-"
    try:
        dt = datetime.strptime(iso[:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        if tz:
            dt = dt.astimezone(tz)
        return dt.strftime("%d-%m-%Y")
    except Exception:
        return iso[:10]


def year_of(match) -> str:
    if match["year"]:
        return str(match["year"])
    created = match["created_at"] or ""
    return created[:4] if len(created) >= 4 else "-"


def video_caption(match, template: str) -> str:
    return template.format(
        team=esc(match["team"]),
        title=esc(match["title"]),
        year=esc(year_of(match)),
    )


def safe_username(username: str | None) -> str:
    if not username:
        return "—"
    return f"@{username}"


def esc(text: str) -> str:
    """HTML এর জন্য টেক্সট এস্কেপ।"""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
