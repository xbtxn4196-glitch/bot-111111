"""অ্যাডমিন প্যানেল — ইউজার, স্ট্যাটস, ব্রডকাস্ট, অ্যাড ম্যানেজার, ম্যাচ, চ্যানেল সিঙ্ক।"""

import asyncio
import math

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import config
from common import get_lang, is_admin, send_admin_panel
from database import Database
from handlers.channel import _copy_to_destination, _clean_caption
from handlers.user import send_video_to
from keyboards import (
    ad_panel_kb,
    ad_preview_kb,
    admin_kb,
    admin_matches_kb,
    back_kb,
    cancel_kb,
    delete_confirm_kb,
    match_admin_kb,
    sync_kb,
    users_kb,
    main_menu_kb,
)
from locales import LANGUAGES, t
from utils import (
    LABEL_ACTIONS,
    esc,
    extract_media,
    fmt_date,
    match_id_from_ref,
    norm,
    parse_caption,
    year_of,
)

router = Router(name="admin")


class Admin(StatesGroup):
    bc = State()
    ad_text = State()
    ad_btn = State()
    ad_url = State()
    edit_team = State()
    edit_title = State()
    manual_video = State()
    manual_info = State()


# ------------------------------------------------------------------ helpers
def _flag(lang: str, value: bool) -> str:
    return t(lang, "ad_on" if value else "ad_off")


async def _guard(cb: CallbackQuery, db: Database) -> tuple[bool, str]:
    lang = await get_lang(db, cb.from_user.id)
    if not await is_admin(db, cb.from_user.id):
        await cb.answer(t(lang, "admin_only"), show_alert=True)
        return False, lang
    return True, lang


async def _safe_edit(cb: CallbackQuery, text: str, kb=None):
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest as exc:
        if "not modified" not in str(exc):
            await cb.message.answer(text, reply_markup=kb)


async def _render_ad_panel(cb: CallbackQuery, db: Database, lang: str):
    s = await db.get_settings("ad_")
    ad_on = s.get("ad_active") == "1" and bool((s.get("ad_text") or "").strip())
    imp_total, imp_users = await db.ad_stats()
    text = t(
        lang,
        "ad_panel",
        status=_flag(lang, ad_on),
        text=esc(s.get("ad_text") or t(lang, "not_set")),
        btn=esc(s.get("ad_btn") or t(lang, "not_set")),
        url=esc(s.get("ad_url") or t(lang, "not_set")),
        imp=f"{imp_total} ({imp_users} 👤)",
    )
    await _safe_edit(cb, text, ad_panel_kb(lang, ad_on, bool((s.get("ad_text") or "").strip())))


async def _render_matches(cb: CallbackQuery, db: Database, lang: str, page: int):
    page = max(1, page)
    size = config.PAGE_ADMIN_MATCHES
    total = await db.count_matches()
    pages = max(1, math.ceil(total / size))
    page = min(page, pages)
    rows = await db.get_matches_latest((page - 1) * size, size)
    if not rows:
        await _safe_edit(cb, t(lang, "no_content"), back_kb(lang, "a:home"))
        return
    text = t(lang, "matches_panel", n=total, p=page, tp=pages)
    await _safe_edit(cb, text, admin_matches_kb(lang, rows, page, total, size))


async def _show_match_card(cb: CallbackQuery, db: Database, lang: str, match_id: int, page: int):
    match = await db.get_match(match_id)
    if not match:
        await _safe_edit(cb, t(lang, "no_content"), back_kb(lang, "a:matches:1"))
        return
    text = t(
        lang,
        "match_card",
        id=match["id"],
        team=esc(match["team"]),
        title=esc(match["title"]),
        year=year_of(match),
        views=match["views"],
        date=fmt_date(match["created_at"]),
    )
    await _safe_edit(cb, text, match_admin_kb(lang, match["id"], page))


async def _channel_status(bot: Bot, chat_id: int) -> str:
    try:
        chat = await bot.get_chat(chat_id)
        title = chat.title or str(chat_id)
        return f"✅ {esc(title)} (<code>{chat_id}</code>)"
    except Exception:  # noqa: BLE001
        return f"❌ <code>{chat_id}</code>"


async def _render_sync(cb: CallbackQuery, db: Database, lang: str, bot: Bot):
    auto_on = (await db.get_setting("autosync")) != "0"
    check = (
        f"📥 {await _channel_status(bot, config.SOURCE_CHANNEL)}\n"
        f"📤 {await _channel_status(bot, config.DEST_CHANNEL)}"
    )
    text = t(
        lang,
        "sync_panel",
        source=config.SOURCE_CHANNEL,
        dest=config.DEST_CHANNEL,
        status=t(lang, "sync_on" if auto_on else "sync_off"),
        check=check,
    )
    await _safe_edit(cb, text, sync_kb(lang, auto_on))


# ------------------------------------------------------------------ entry points
@router.message(Command("admin"), F.chat.type == "private")
async def cmd_admin(message: Message, db: Database):
    uid = message.from_user.id
    lang = await get_lang(db, uid)
    if await is_admin(db, uid):
        await send_admin_panel(message, db, lang)
        return
    owner = await db.get_setting("owner_id")
    if not owner:
        # প্রথম /admin যে দেবে সে-ই owner (বটের সেটআপ সহজ করতে)
        await db.set_setting("owner_id", str(uid))
        await message.answer(
            t(lang, "owner_assigned"), reply_markup=main_menu_kb(lang, True)
        )
        await send_admin_panel(message, db, lang)
        return
    await message.answer(t(lang, "admin_only"))


@router.message(Command("cancel"), F.chat.type == "private")
async def cmd_cancel(message: Message, state: FSMContext, db: Database):
    await state.clear()
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "bc_cancelled"))


# ------------------------------------------------------------------ panel core
@router.callback_query(F.data == "a:home")
async def cb_home(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    await _safe_edit(cb, t(lang, "ap_title"), admin_kb(lang))
    await cb.answer()


@router.callback_query(F.data == "a:stats")
async def cb_stats(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    ad_imp, ad_users = await db.ad_stats()
    text = t(
        lang,
        "stats_text",
        users=await db.count_users(),
        new_today=await db.count_new_today(),
        active_today=await db.count_active_today(),
        matches=await db.count_matches(),
        views=await db.total_views(),
        ad_imp=ad_imp,
        ad_users=ad_users,
    )
    await _safe_edit(cb, text, admin_kb(lang))
    await cb.answer()


# ------------------------------------------------------------------ users
@router.callback_query(F.data.startswith("a:users:"))
async def cb_users(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        page = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        page = 1
    total = await db.count_users()
    pages = max(1, math.ceil(total / config.PAGE_USERS))
    page = min(max(1, page), pages)
    users = await db.get_users_page((page - 1) * config.PAGE_USERS, config.PAGE_USERS)

    lines = [t(lang, "users_header", n=total, p=page, tp=pages)]
    for u in users:
        uname = f" · @{u['username']}" if u["username"] else ""
        lines.append(
            t(
                lang,
                "user_line",
                name=esc(u["first_name"] or "—"),
                id=u["id"],
                lang=LANGUAGES.get(u["lang"] or "", "—"),
                username=esc(uname),
                date=fmt_date(u["created_at"]),
            )
        )
    await _safe_edit(cb, "\n\n".join(lines), users_kb(lang, page, pages))
    await cb.answer()


# ------------------------------------------------------------------ broadcast
@router.callback_query(F.data == "a:bc")
async def cb_broadcast(cb: CallbackQuery, state: FSMContext, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    await state.set_state(Admin.bc)
    await _safe_edit(cb, t(lang, "bc_prompt"), cancel_kb(lang, "a:home"))
    await cb.answer()


@router.message(Admin.bc, F.chat.type == "private")
async def do_broadcast(message: Message, state: FSMContext, db: Database):
    lang = await get_lang(db, message.from_user.id)
    if message.text and (message.text in LABEL_ACTIONS or message.text.startswith("/")):
        await state.clear()
        await message.answer(t(lang, "bc_cancelled"))
        return

    users = await db.get_all_user_ids()
    await message.answer(t(lang, "bc_started", n=len(users)))
    sent = fail = 0
    for index, uid in enumerate(users, start=1):
        try:
            await message.copy_to(uid)
            sent += 1
        except Exception:  # noqa: BLE001
            fail += 1
        if index % config.MAX_BROADCAST_PER_SECOND == 0:
            await asyncio.sleep(1.0)
    await state.clear()
    await message.answer(t(lang, "bc_done", ok=sent, fail=fail))


# ------------------------------------------------------------------ ad manager
@router.callback_query(F.data == "a:ad")
async def cb_ad(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    await _render_ad_panel(cb, db, lang)
    await cb.answer()


@router.callback_query(F.data.startswith("a:ad:"))
async def cb_ad_action(cb: CallbackQuery, state: FSMContext, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    action = cb.data.split(":", 2)[2]

    if action == "text":
        await state.set_state(Admin.ad_text)
        await _safe_edit(cb, t(lang, "ad_enter_text"), cancel_kb(lang, "a:ad"))
        await cb.answer()
        return

    if action == "btn":
        await state.set_state(Admin.ad_btn)
        await _safe_edit(cb, t(lang, "ad_enter_btn"), cancel_kb(lang, "a:ad"))
        await cb.answer()
        return

    if action == "url":
        await state.set_state(Admin.ad_url)
        await _safe_edit(cb, t(lang, "ad_enter_url"), cancel_kb(lang, "a:ad"))
        await cb.answer()
        return

    if action == "toggle":
        s = await db.get_settings("ad_")
        if not (s.get("ad_text") or "").strip():
            await cb.answer(t(lang, "ad_need_text"), show_alert=True)
            return
        new_value = "0" if s.get("ad_active") == "1" else "1"
        await db.set_setting("ad_active", new_value)
        await _render_ad_panel(cb, db, lang)
        await cb.answer()
        return

    if action == "clear":
        for key in ("ad_text", "ad_btn", "ad_url", "ad_active"):
            await db.set_setting(key, None)
        await _render_ad_panel(cb, db, lang)
        await cb.answer(t(lang, "ad_cleared"), show_alert=True)
        return

    if action == "preview":
        s = await db.get_settings("ad_")
        text = f"{t(lang, 'ad_header')}\n\n{esc(s.get('ad_text') or '')}\n\n{t(lang, 'ad_note')}"
        kb = ad_preview_kb(lang, s.get("ad_url") or "", s.get("ad_btn") or "")
        await _safe_edit(cb, text, kb)
        await cb.answer()
        return

    await cb.answer()


def _is_escape(text: str) -> bool:
    return text in LABEL_ACTIONS or text.startswith("/")


@router.message(Admin.ad_text, F.chat.type == "private", F.text)
async def ad_save_text(message: Message, state: FSMContext, db: Database):
    if _is_escape(message.text):
        await state.clear()
        lang = await get_lang(db, message.from_user.id)
        await message.answer(t(lang, "bc_cancelled"), reply_markup=main_menu_kb(lang, True))
        return
    await db.set_setting("ad_text", message.text.strip()[:900])
    await state.clear()
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "ad_saved"), reply_markup=admin_kb(lang))


@router.message(Admin.ad_btn, F.chat.type == "private", F.text)
async def ad_save_btn(message: Message, state: FSMContext, db: Database):
    if _is_escape(message.text):
        await state.clear()
        lang = await get_lang(db, message.from_user.id)
        await message.answer(t(lang, "bc_cancelled"), reply_markup=main_menu_kb(lang, True))
        return
    await db.set_setting("ad_btn", message.text.strip()[:64])
    await state.clear()
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "ad_saved"), reply_markup=admin_kb(lang))


@router.message(Admin.ad_url, F.chat.type == "private", F.text)
async def ad_save_url(message: Message, state: FSMContext, db: Database):
    lang = await get_lang(db, message.from_user.id)
    text = message.text.strip()
    if text in LABEL_ACTIONS:
        await state.clear()
        await message.answer(t(lang, "bc_cancelled"), reply_markup=main_menu_kb(lang, True))
        return
    if text == "/skip":
        await db.set_setting("ad_url", None)
    elif text.startswith("http://") or text.startswith("https://") or text.startswith("tg://"):
        await db.set_setting("ad_url", text[:500])
    else:
        await message.answer(t(lang, "ad_enter_url"))
        return
    await state.clear()
    await message.answer(t(lang, "ad_saved"), reply_markup=admin_kb(lang))


# ------------------------------------------------------------------ matches
@router.callback_query(F.data.startswith("a:matches:"))
async def cb_matches(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        page = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        page = 1
    await _render_matches(cb, db, lang, page)
    await cb.answer()


@router.callback_query(F.data.startswith("pg:mt:"))
async def cb_matches_page(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        page = int(cb.data.split(":")[3])
    except (IndexError, ValueError):
        page = 1
    await _render_matches(cb, db, lang, page)
    await cb.answer()


@router.callback_query(F.data.startswith("am:"))
async def cb_match_card(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        _, raw_id, page_raw = cb.data.split(":", 2)
        match_id, page = int(raw_id), int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    await _show_match_card(cb, db, lang, match_id, page)
    await cb.answer()


@router.callback_query(F.data.startswith("amd:"))
async def cb_match_send_me(cb: CallbackQuery, db: Database, bot: Bot):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    match_id = match_id_from_ref(cb.data.split(":", 1)[1])
    match = await db.get_match(match_id) if match_id else None
    if not match:
        await cb.answer(t(lang, "video_unavailable"), show_alert=True)
        return
    await cb.answer(t(lang, "delivering"))
    await send_video_to(bot, db, cb.from_user.id, match, lang)


@router.callback_query(F.data.startswith("emt:"))
async def cb_edit_team(cb: CallbackQuery, state: FSMContext, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        _, raw_id, page_raw = cb.data.split(":", 2)
        match_id, page = int(raw_id), int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    await state.set_state(Admin.edit_team)
    await state.update_data(match_id=match_id, page=page)
    await _safe_edit(cb, t(lang, "me_team_prompt", id=match_id), cancel_kb(lang, f"am:{match_id}:{page}"))
    await cb.answer()


@router.message(Admin.edit_team, F.chat.type == "private", F.text)
async def save_team_name(message: Message, state: FSMContext, db: Database):
    lang = await get_lang(db, message.from_user.id)
    if message.text in LABEL_ACTIONS or message.text.startswith("/"):
        await state.clear()
        await message.answer(t(lang, "bc_cancelled"))
        return
    data = await state.get_data()
    match_id = data.get("match_id", 0)
    new_team = message.text.strip()[:60]
    await db.update_match(match_id, team=new_team, team_key=norm(new_team))
    await state.clear()
    await message.answer(t(lang, "saved_ok"), reply_markup=main_menu_kb(lang, True))


@router.callback_query(F.data.startswith("emz:"))
async def cb_edit_title(cb: CallbackQuery, state: FSMContext, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        _, raw_id, page_raw = cb.data.split(":", 2)
        match_id, page = int(raw_id), int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    await state.set_state(Admin.edit_title)
    await state.update_data(match_id=match_id, page=page)
    await _safe_edit(cb, t(lang, "me_title_prompt", id=match_id), cancel_kb(lang, f"am:{match_id}:{page}"))
    await cb.answer()


@router.message(Admin.edit_title, F.chat.type == "private", F.text)
async def save_match_title(message: Message, state: FSMContext, db: Database):
    lang = await get_lang(db, message.from_user.id)
    if message.text in LABEL_ACTIONS or message.text.startswith("/"):
        await state.clear()
        await message.answer(t(lang, "bc_cancelled"))
        return
    data = await state.get_data()
    match_id = data.get("match_id", 0)
    await db.update_match(match_id, title=message.text.strip()[:200])
    await state.clear()
    await message.answer(t(lang, "saved_ok"), reply_markup=main_menu_kb(lang, True))


@router.callback_query(F.data.startswith("adm:"))
async def cb_delete_ask(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        _, raw_id, page_raw = cb.data.split(":", 2)
        match_id, page = int(raw_id), int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    await _safe_edit(cb, t(lang, "delete_confirm", id=match_id), delete_confirm_kb(lang, match_id, page))
    await cb.answer()


@router.callback_query(F.data.startswith("admy:"))
async def cb_delete_yes(cb: CallbackQuery, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    try:
        _, raw_id, page_raw = cb.data.split(":", 2)
        match_id, page = int(raw_id), int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    await db.delete_match(match_id)
    await cb.answer(t(lang, "deleted_ok"), show_alert=True)
    await _render_matches(cb, db, lang, page)


# ------------------------------------------------------------------ sync
@router.callback_query(F.data == "a:sync")
async def cb_sync(cb: CallbackQuery, db: Database, bot: Bot):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    await _render_sync(cb, db, lang, bot)
    await cb.answer()


@router.callback_query(F.data.startswith("a:sync:"))
async def cb_sync_action(cb: CallbackQuery, db: Database, bot: Bot):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    action = cb.data.split(":", 2)[2]
    if action == "toggle":
        current = await db.get_setting("autosync")
        await db.set_setting("autosync", "0" if current != "0" else "1")
    await _render_sync(cb, db, lang, bot)
    await cb.answer()


# ------------------------------------------------------------------ manual add
@router.callback_query(F.data == "a:manual")
async def cb_manual(cb: CallbackQuery, state: FSMContext, db: Database):
    ok, lang = await _guard(cb, db)
    if not ok:
        return
    await state.set_state(Admin.manual_video)
    await _safe_edit(cb, t(lang, "manual_prompt_video"), cancel_kb(lang, "a:home"))
    await cb.answer()


@router.message(Admin.manual_video, F.chat.type == "private")
async def manual_take_video(message: Message, state: FSMContext, db: Database):
    lang = await get_lang(db, message.from_user.id)
    media_type, file_id, _ = extract_media(message)
    if not media_type:
        if message.text and message.text.startswith("/"):
            await state.clear()
            await message.answer(t(lang, "bc_cancelled"))
            return
        await message.answer(t(lang, "manual_prompt_video"))
        return
    await state.update_data(file_id=file_id, media_type=media_type)
    await state.set_state(Admin.manual_info)
    await message.answer(t(lang, "manual_prompt_info"))


@router.message(Admin.manual_info, F.chat.type == "private", F.text)
async def manual_take_info(message: Message, state: FSMContext, db: Database, bot: Bot):
    lang = await get_lang(db, message.from_user.id)
    text = message.text.strip()
    if text.startswith("/"):
        await state.clear()
        await message.answer(t(lang, "bc_cancelled"))
        return

    parsed = parse_caption(text)
    if "|" in text:
        left, right = text.split("|", 1)
        team, title = left.strip(), right.strip()
    elif parsed["team"] and parsed["title"]:
        team, title = parsed["team"], parsed["title"]
    else:
        team = title = ""

    if not team or not title:
        await message.answer(t(lang, "manual_bad_format"))
        return

    data = await state.get_data()
    file_id, media_type = data.get("file_id"), data.get("media_type", "video")
    if not file_id:
        await state.clear()
        await message.answer(t(lang, "manual_prompt_video"))
        return

    posted, dest_msg = await _copy_to_destination(
        bot, media_type, file_id, _clean_caption(team, title, parsed["year"])
    )
    await db.add_match(
        team=team,
        team_key=norm(team),
        title=title,
        year=parsed["year"],
        tags=parsed["tags"],
        file_id=file_id,
        media_type=media_type,
        dest_msg=dest_msg,
    )
    await state.clear()
    await message.answer(
        t(lang, "manual_saved", team=esc(team), title=esc(title)),
        reply_markup=main_menu_kb(lang, True),
    )
