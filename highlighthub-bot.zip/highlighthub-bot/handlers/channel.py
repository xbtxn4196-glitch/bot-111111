"""সোর্স চ্যানেলের নতুন হাইলাইট → ডেটাবেসে সেভ + ডেস্টিনেশন চ্যানেলে অটো-পোস্ট।"""

import logging
from datetime import timedelta

from aiogram import Bot, F, Router
from aiogram.types import Message

import config
from common import admin_ids
from database import Database
from locales import t
from utils import esc, extract_media, message_text_or_caption, norm, parse_caption

router = Router(name="channel")
log = logging.getLogger(__name__)


def _clean_caption(team: str, title: str, year: str) -> str:
    """চ্যানেলে যাওয়া ক্যাপশন — সব লিংক/ইউজারনেম বাদ।"""
    lines = [f"🎬 <b>{esc(title)}</b>", f"🏆 {esc(team)}"]
    if year:
        lines.append(f"📅 {year}")
    return "\n".join(lines)


async def _copy_to_destination(bot: Bot, media_type: str, file_id: str, caption: str) -> tuple[bool, int]:
    if not config.DEST_CHANNEL or config.DEST_CHANNEL == config.SOURCE_CHANNEL:
        return False, 0
    try:
        if media_type == "animation":
            sent = await bot.send_animation(
                config.DEST_CHANNEL, file_id, caption=caption, parse_mode="HTML"
            )
        elif media_type == "document":
            sent = await bot.send_document(
                config.DEST_CHANNEL, file_id, caption=caption, parse_mode="HTML"
            )
        else:
            sent = await bot.send_video(
                config.DEST_CHANNEL, file_id, caption=caption, parse_mode="HTML"
            )
        return True, sent.message_id
    except Exception as exc:  # noqa: BLE001
        log.warning("Destination copy failed: %s", exc)
        return False, 0


@router.channel_post(F.chat.id == config.SOURCE_CHANNEL)
async def on_source_channel_post(message: Message, bot: Bot, db: Database):
    # ২৪ ঘণ্টার বেশি পুরোনো পোস্ট ইগনোর (বট বন্ধ থাকলে মিস হওয়া ভিডিওগুলোও ধরা পড়বে)
    if message.date < config.STARTED_AT - timedelta(hours=24):
        return

    # একই পোস্ট দুইবার সেভ হবে না
    if await db.get_match_by_source(message.message_id):
        return

    # অটো-সিঙ্ক বন্ধ থাকলে কিছুই করবে না
    if await db.get_setting("autosync") == "0":
        return

    media_type, file_id, _ = extract_media(message)
    if not media_type:
        return  # টেক্সট ছাড়া অন্য কিছু (ছবি/টেক্সট পোস্ট) ইগনোর

    info = parse_caption(message_text_or_caption(message))
    team, title, year, tags = info["team"], info["title"], info["year"], info["tags"]

    posted, dest_msg_id = await _copy_to_destination(
        bot, media_type, file_id, _clean_caption(team, title, year)
    )

    await db.add_match(
        team=team,
        team_key=norm(team),
        title=title,
        year=year,
        tags=tags,
        file_id=file_id,
        media_type=media_type,
        source_msg=message.message_id,
        dest_msg=dest_msg_id,
    )

    for admin_id in await admin_ids(db):
        row = await db.get_user(admin_id)
        lang = (row["lang"] if row and row["lang"] else config.DEFAULT_LANG) or "bn"
        if posted:
            posted_text = t(lang, "capture_posted")
        elif config.DEST_CHANNEL == config.SOURCE_CHANNEL:
            posted_text = "↩️ " + t(lang, "capture_posted")
        else:
            posted_text = t(lang, "capture_failed")
        text = t(
            lang,
            "capture_notice",
            team=esc(team),
            title=esc(title),
            year=year or t(lang, "not_set"),
            posted=posted_text,
        )
        try:
            await bot.send_message(admin_id, text)
        except Exception:
            continue
