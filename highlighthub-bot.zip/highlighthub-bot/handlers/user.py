"""ইউজার সাইড — মেনু, সার্চ, লিস্ট, ভিডিও ডেলিভারি ও অ্যাড গেট।"""

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import config
from common import get_lang, is_admin, send_admin_panel
from database import Database
from keyboards import (
    ad_kb,
    back_kb,
    lang_kb,
    main_menu_kb,
    match_buttons,
    team_buttons,
)
from locales import LANGUAGES, t
from utils import (
    LABEL_ACTIONS,
    esc,
    load_ad,
    match_id_from_ref,
    resolve_team_ref,
    search_matches,
    suggest_teams,
    video_caption,
)

router = Router(name="user")


class Search(StatesGroup):
    query = State()


# প্রতি ইউজারের শেষ সার্চ (query, [match ids])
SEARCH_CACHE: dict[int, tuple[str, list[int]]] = {}


# ------------------------------------------------------------------ helpers
def _name(user) -> str:
    return esc(user.first_name or "Friend")


def _short(text: str, limit: int = 60) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


async def _menu_keyboard(db: Database, user_id: int, lang: str):
    return main_menu_kb(lang, await is_admin(db, user_id))


async def send_welcome(message: Message, db: Database, lang: str, user_id: int):
    await message.answer(
        t(lang, "welcome", name=_name(message.from_user)),
        reply_markup=await _menu_keyboard(db, user_id, lang),
    )


async def send_video_to(bot: Bot, db: Database, chat_id: int, match, lang: str) -> bool:
    """ম্যাচের ভিডিও পাঠায় (কোনো লিংক ছাড়া, শুধু file_id)।"""
    caption = video_caption(match, config.VIDEO_CAPTION_TEMPLATE)
    try:
        if match["media_type"] == "animation":
            await bot.send_animation(chat_id, match["file_id"], caption=caption, parse_mode="HTML")
        elif match["media_type"] == "document":
            await bot.send_document(chat_id, match["file_id"], caption=caption, parse_mode="HTML")
        else:
            await bot.send_video(chat_id, match["file_id"], caption=caption, parse_mode="HTML")
        await db.increment_views(match["id"])
        return True
    except TelegramBadRequest:
        await bot.send_message(chat_id, t(lang, "video_unavailable"))
        return False


async def build_list(db: Database, lang: str, kind: str, page: int, ref: str, user_id: int):
    """(text, keyboard) রিটার্ন করে; কিছু না থাকলে None।"""
    page = max(1, int(page))
    size = config.PAGE_MATCHES

    if kind in ("l", "p"):
        total = await db.count_matches()
        if total == 0:
            return None
        offset = (page - 1) * size
        if kind == "l":
            rows = await db.get_matches_latest(offset, size)
            header = t(lang, "latest_header", n=total)
        else:
            rows = await db.get_matches_popular(offset, size)
            header = t(lang, "popular_header", n=total)
        kb = match_buttons(lang, rows, page, total, size, kind, "")
        return header, kb

    if kind == "sr":
        cached = SEARCH_CACHE.get(user_id)
        if not cached or not cached[1]:
            return None
        query, ids = cached
        offset = (page - 1) * size
        rows = await db.get_matches_by_ids(ids[offset : offset + size])
        if not rows:
            return None
        header = t(lang, "search_results", q=esc(_short(query)), n=len(ids))
        kb = match_buttons(lang, rows, page, len(ids), size, "sr", "")
        return header, kb

    if kind == "tm":
        team_key = await resolve_team_ref(db, ref)
        if not team_key:
            return None
        total = await db.count_team_matches(team_key)
        if total == 0:
            return None
        offset = (page - 1) * size
        rows = await db.get_team_matches(team_key, offset, size)
        team_name = rows[0]["team"] if rows else team_key
        header = t(lang, "team_header", team=esc(team_name), n=total)
        kb = match_buttons(lang, rows, page, total, size, "tm", ref, back_cb="home")
        return header, kb

    if kind == "tl":
        teams = await db.get_teams()
        if not teams:
            return None
        size_t = config.PAGE_TEAMS
        offset = (page - 1) * size_t
        chunk = teams[offset : offset + size_t]
        if not chunk:
            return None
        header = t(lang, "teams_header", n=len(teams))
        kb = team_buttons(lang, chunk, page, len(teams), size_t, back_cb="home")
        return header, kb

    return None


async def _edit_or_send(cb: CallbackQuery, text: str, kb):
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest as exc:
        if "not modified" not in str(exc):
            await cb.message.answer(text, reply_markup=kb)


async def _do_search(message: Message, db: Database, lang: str) -> None:
    query = (message.text or "").strip()
    rows = await db.get_search_index()
    found = search_matches(rows, query, limit=config.SEARCH_LIMIT)
    ids = [r["id"] for r in found]
    SEARCH_CACHE[message.from_user.id] = (query, ids)

    if not ids:
        teams = await db.get_teams()
        suggestions = suggest_teams(teams, query)
        text = t(lang, "search_empty")
        if suggestions:
            text += "\n\n" + t(lang, "search_suggest") + "\n" + "\n".join(
                f"• {esc(s)}" for s in suggestions
            )
        await message.answer(text)
        return

    header = t(lang, "search_results", q=esc(_short(query)), n=len(ids))
    kb = match_buttons(lang, found[: config.PAGE_MATCHES], 1, len(ids), config.PAGE_MATCHES, "sr", "")
    await message.answer(header, reply_markup=kb)


# ------------------------------------------------------------------ commands
@router.message(Command("start"), F.chat.type == "private")
async def cmd_start(message: Message, state: FSMContext, db: Database):
    user = message.from_user
    await state.clear()
    await db.add_or_update_user(user.id, user.first_name or "", user.username or "")
    row = await db.get_user(user.id)
    lang = (row["lang"] if row and row["lang"] else config.DEFAULT_LANG) or "bn"
    if lang not in LANGUAGES:
        lang = "bn"
    if not (row and row["lang"]):
        await message.answer(t(lang, "choose_lang"), reply_markup=lang_kb())
    await send_welcome(message, db, lang, user.id)


@router.message(Command("help"), F.chat.type == "private")
async def cmd_help(message: Message, db: Database):
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "help_text"), reply_markup=back_kb(lang, "home"))


@router.message(Command("lang"), F.chat.type == "private")
async def cmd_lang(message: Message, db: Database):
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "choose_lang"), reply_markup=lang_kb())


@router.message(Command("cancel"), F.chat.type == "private")
async def cmd_cancel(message: Message, state: FSMContext, db: Database):
    await state.clear()
    lang = await get_lang(db, message.from_user.id)
    await message.answer(t(lang, "bc_cancelled"))


# ------------------------------------------------------------------ language
@router.callback_query(F.data.startswith("lang:"))
async def on_lang_choice(cb: CallbackQuery, db: Database):
    code = cb.data.split(":", 1)[1]
    if code not in LANGUAGES:
        await cb.answer()
        return
    user = cb.from_user
    await db.add_or_update_user(user.id, user.first_name or "", user.username or "", lang=code)
    try:
        await cb.message.edit_text(t(code, "lang_set", lang=LANGUAGES[code]))
    except TelegramBadRequest:
        pass
    await cb.message.answer(
        t(code, "welcome", name=_name(user)),
        reply_markup=await _menu_keyboard(db, user.id, code),
    )
    await cb.answer()


# ------------------------------------------------------------------ menu
@router.message(F.chat.type == "private", F.text.in_(set(LABEL_ACTIONS.keys())))
async def on_menu(message: Message, state: FSMContext, db: Database):
    action = LABEL_ACTIONS[message.text]
    await state.clear()
    lang = await get_lang(db, message.from_user.id)

    if action == "search":
        await message.answer(t(lang, "search_prompt"))
        await state.set_state(Search.query)
        return

    if action in ("popular", "latest", "teams"):
        kind = {"popular": "p", "latest": "l", "teams": "tl"}[action]
        result = await build_list(db, lang, kind, 1, "", message.from_user.id)
        if not result:
            await message.answer(t(lang, "no_content"))
            return
        text, kb = result
        await message.answer(text, reply_markup=kb)
        return

    if action == "lang":
        await message.answer(t(lang, "choose_lang"), reply_markup=lang_kb())
        return

    if action == "help":
        await message.answer(t(lang, "help_text"), reply_markup=back_kb(lang, "home"))
        return

    if action == "admin":
        if not await is_admin(db, message.from_user.id):
            await message.answer(t(lang, "admin_only"))
            return
        await send_admin_panel(message, db, lang)
        return

    # menu / home
    await send_welcome(message, db, lang, message.from_user.id)


# ------------------------------------------------------------------ search
@router.message(Search.query, F.chat.type == "private")
async def on_search_state(message: Message, db: Database):
    lang = await get_lang(db, message.from_user.id)
    text = (message.text or "").strip()
    if not text or text.startswith("/"):
        return
    if len(text) < 2:
        await message.answer(t(lang, "search_prompt"))
        return
    await _do_search(message, db, lang)


@router.message(F.chat.type == "private", F.text)
async def on_any_text(message: Message, state: FSMContext, db: Database):
    """মেনুর বাইরে কেউ সরাসরি নাম লিখলেও সার্চ হবে।"""
    text = (message.text or "").strip()
    if not text or text.startswith("/"):
        return
    lang = await get_lang(db, message.from_user.id)
    if len(text) < 2:
        await message.answer(t(lang, "search_prompt"))
        return
    await state.clear()
    await _do_search(message, db, lang)


# ------------------------------------------------------------------ callbacks
@router.callback_query(F.data == "noop")
async def on_noop(cb: CallbackQuery):
    await cb.answer()


@router.callback_query(F.data == "home")
async def on_home(cb: CallbackQuery, db: Database):
    lang = await get_lang(db, cb.from_user.id)
    await cb.message.answer(
        t(lang, "welcome", name=_name(cb.from_user)),
        reply_markup=await _menu_keyboard(db, cb.from_user.id, lang),
    )
    await cb.answer()


@router.callback_query(F.data.startswith("pg:"))
async def on_page(cb: CallbackQuery, db: Database):
    try:
        _, kind, ref, page_raw = cb.data.split(":", 3)
        page = int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    lang = await get_lang(db, cb.from_user.id)
    result = await build_list(db, lang, kind, page, ref, cb.from_user.id)
    if not result:
        await cb.answer(t(lang, "no_content"))
        return
    text, kb = result
    await _edit_or_send(cb, text, kb)
    await cb.answer()


@router.callback_query(F.data.startswith("tm:"))
async def on_team_click(cb: CallbackQuery, db: Database):
    try:
        _, ref, page_raw = cb.data.split(":", 2)
        page = int(page_raw)
    except (ValueError, IndexError):
        await cb.answer()
        return
    lang = await get_lang(db, cb.from_user.id)
    result = await build_list(db, lang, "tm", page, ref, cb.from_user.id)
    if not result:
        await cb.answer(t(lang, "no_team_content"))
        return
    text, kb = result
    await _edit_or_send(cb, text, kb)
    await cb.answer()


@router.callback_query(F.data.startswith("v:"))
async def on_video_click(cb: CallbackQuery, db: Database, bot: Bot):
    match_id = match_id_from_ref(cb.data[2:])
    lang = await get_lang(db, cb.from_user.id)
    match = await db.get_match(match_id) if match_id else None
    if not match:
        await cb.answer(t(lang, "video_unavailable"), show_alert=False)
        return

    ad = await load_ad(db)
    if ad:
        await db.register_ad_view(cb.from_user.id)
        text = f"{t(lang, 'ad_header')}\n\n{esc(ad['text'])}\n\n{t(lang, 'ad_note')}"
        kb = ad_kb(lang, match_id, ad["url"], ad["btn"])
        try:
            await cb.message.edit_text(text, reply_markup=kb, disable_web_page_preview=True)
        except TelegramBadRequest:
            await cb.message.answer(text, reply_markup=kb, disable_web_page_preview=True)
        await cb.answer()
        return

    await cb.answer(t(lang, "delivering"))
    await send_video_to(bot, db, cb.message.chat.id, match, lang)


@router.callback_query(F.data.startswith("vx:"))
async def on_video_after_ad(cb: CallbackQuery, db: Database, bot: Bot):
    match_id = match_id_from_ref(cb.data[3:])
    lang = await get_lang(db, cb.from_user.id)
    match = await db.get_match(match_id) if match_id else None
    if not match:
        await cb.answer(t(lang, "video_unavailable"), show_alert=False)
        return
    await cb.answer(t(lang, "delivering"))
    await send_video_to(bot, db, cb.message.chat.id, match, lang)
