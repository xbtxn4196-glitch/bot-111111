"""SQLite ডাটাবেজ — ইউজার, ম্যাচ, সেটিংস ও অ্যাড ক্লিক।"""

import asyncio
from datetime import datetime, timezone
from pathlib import Path

import aiosqlite

from config import DB_PATH


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")


def utcnow_iso() -> str:
    return _iso(datetime.now(timezone.utc))


class Database:
    def __init__(self, path: str = DB_PATH):
        self.path = path
        self._db: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    # ------------------------------------------------------------------ setup
    async def connect(self) -> None:
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._db = await aiosqlite.connect(self.path)
        self._db.row_factory = aiosqlite.Row
        await self._db.execute("PRAGMA journal_mode=WAL")
        await self._create_tables()

    async def _create_tables(self) -> None:
        await self._db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id          INTEGER PRIMARY KEY,
                first_name  TEXT DEFAULT '',
                username    TEXT DEFAULT '',
                lang        TEXT DEFAULT '',
                created_at  TEXT,
                last_active TEXT
            );

            CREATE TABLE IF NOT EXISTS matches (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                team        TEXT NOT NULL,
                team_key    TEXT NOT NULL,
                title       TEXT NOT NULL,
                year        TEXT DEFAULT '',
                tags        TEXT DEFAULT '',
                file_id     TEXT NOT NULL,
                media_type  TEXT DEFAULT 'video',
                source_msg  INTEGER DEFAULT 0,
                dest_msg    INTEGER DEFAULT 0,
                views       INTEGER DEFAULT 0,
                created_at  TEXT
            );

            CREATE INDEX IF NOT EXISTS idx_matches_team_key ON matches(team_key);
            CREATE INDEX IF NOT EXISTS idx_matches_created ON matches(created_at);

            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );

            CREATE TABLE IF NOT EXISTS ad_views (
                user_id    INTEGER PRIMARY KEY,
                views      INTEGER DEFAULT 0,
                last_view  TEXT
            );
            """
        )
        await self._db.commit()

    async def close(self) -> None:
        if self._db:
            await self._db.close()

    # ------------------------------------------------------------------ users
    async def add_or_update_user(
        self,
        user_id: int,
        first_name: str = "",
        username: str = "",
        lang: str | None = None,
    ) -> None:
        now = utcnow_iso()
        async with self._lock:
            row = await self._fetchone("SELECT id, lang FROM users WHERE id = ?", (user_id,))
            if row is None:
                await self._db.execute(
                    "INSERT INTO users (id, first_name, username, lang, created_at, last_active) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (user_id, first_name or "", username or "", lang or "", now, now),
                )
            else:
                if lang:
                    await self._db.execute(
                        "UPDATE users SET first_name=?, username=?, lang=?, last_active=? WHERE id=?",
                        (first_name or "", username or "", lang, now, user_id),
                    )
                else:
                    await self._db.execute(
                        "UPDATE users SET first_name=?, username=?, last_active=? WHERE id=?",
                        (first_name or "", username or "", now, user_id),
                    )
            await self._db.commit()

    async def touch_user(self, user_id: int) -> None:
        async with self._lock:
            await self._db.execute(
                "UPDATE users SET last_active=? WHERE id=?", (utcnow_iso(), user_id)
            )
            await self._db.commit()

    async def set_user_lang(self, user_id: int, lang: str) -> None:
        async with self._lock:
            await self._db.execute("UPDATE users SET lang=? WHERE id=?", (lang, user_id))
            await self._db.commit()

    async def get_user(self, user_id: int):
        return await self._fetchone("SELECT * FROM users WHERE id = ?", (user_id,))

    async def get_all_user_ids(self) -> list[int]:
        rows = await self._fetchall("SELECT id FROM users ORDER BY id")
        return [r["id"] for r in rows]

    async def get_users_page(self, offset: int, limit: int) -> list:
        return await self._fetchall(
            "SELECT * FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?", (limit, offset)
        )

    async def count_users(self) -> int:
        row = await self._fetchone("SELECT COUNT(*) AS c FROM users")
        return row["c"] if row else 0

    async def count_new_today(self) -> int:
        start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        row = await self._fetchone(
            "SELECT COUNT(*) AS c FROM users WHERE created_at >= ?", (_iso(start),)
        )
        return row["c"] if row else 0

    async def count_active_today(self) -> int:
        start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        row = await self._fetchone(
            "SELECT COUNT(*) AS c FROM users WHERE last_active >= ?", (_iso(start),)
        )
        return row["c"] if row else 0

    # ------------------------------------------------------------------ matches
    async def add_match(
        self,
        team: str,
        team_key: str,
        title: str,
        year: str,
        tags: str,
        file_id: str,
        media_type: str,
        source_msg: int = 0,
        dest_msg: int = 0,
    ) -> int:
        async with self._lock:
            cur = await self._db.execute(
                "INSERT INTO matches (team, team_key, title, year, tags, file_id, media_type, "
                "source_msg, dest_msg, views, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)",
                (team, team_key, title, year or "", tags or "", file_id, media_type, source_msg, dest_msg, utcnow_iso()),
            )
            await self._db.commit()
            return int(cur.lastrowid)

    async def get_match_by_source(self, source_msg: int):
        return await self._fetchone(
            "SELECT * FROM matches WHERE source_msg = ? AND source_msg != 0", (source_msg,)
        )

    async def get_match(self, match_id: int):
        return await self._fetchone("SELECT * FROM matches WHERE id = ?", (match_id,))

    async def get_matches_latest(self, offset: int = 0, limit: int = 6) -> list:
        return await self._fetchall(
            "SELECT * FROM matches ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
            (limit, offset),
        )

    async def get_matches_popular(self, offset: int = 0, limit: int = 6) -> list:
        return await self._fetchall(
            "SELECT * FROM matches ORDER BY views DESC, created_at DESC, id DESC LIMIT ? OFFSET ?",
            (limit, offset),
        )

    async def get_team_matches(self, team_key: str, offset: int = 0, limit: int = 6) -> list:
        return await self._fetchall(
            "SELECT * FROM matches WHERE team_key = ? ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
            (team_key, limit, offset),
        )

    async def count_matches(self) -> int:
        row = await self._fetchone("SELECT COUNT(*) AS c FROM matches")
        return row["c"] if row else 0

    async def count_team_matches(self, team_key: str) -> int:
        row = await self._fetchone(
            "SELECT COUNT(*) AS c FROM matches WHERE team_key = ?", (team_key,)
        )
        return row["c"] if row else 0

    async def total_views(self) -> int:
        row = await self._fetchone("SELECT COALESCE(SUM(views), 0) AS s FROM matches")
        return row["s"] if row else 0

    async def increment_views(self, match_id: int) -> None:
        async with self._lock:
            await self._db.execute("UPDATE matches SET views = views + 1 WHERE id = ?", (match_id,))
            await self._db.commit()

    async def update_match(self, match_id: int, **fields) -> None:
        allowed = {"team", "team_key", "title", "year", "tags", "file_id", "media_type"}
        sets, values = [], []
        for key, value in fields.items():
            if key in allowed:
                sets.append(f"{key} = ?")
                values.append(value)
        if not sets:
            return
        values.append(match_id)
        async with self._lock:
            await self._db.execute(f"UPDATE matches SET {', '.join(sets)} WHERE id = ?", values)
            await self._db.commit()

    async def delete_match(self, match_id: int) -> None:
        async with self._lock:
            await self._db.execute("DELETE FROM matches WHERE id = ?", (match_id,))
            await self._db.commit()

    async def get_teams(self) -> list:
        return await self._fetchall(
            "SELECT team, team_key, COUNT(*) AS total FROM matches "
            "GROUP BY team_key ORDER BY total DESC, team ASC"
        )

    async def get_search_index(self) -> list:
        return await self._fetchall(
            "SELECT id, team, team_key, title, year, tags, views, created_at FROM matches "
            "ORDER BY created_at DESC, id DESC"
        )

    # ------------------------------------------------------------------ settings
    async def set_setting(self, key: str, value: str | None) -> None:
        async with self._lock:
            if value is None:
                await self._db.execute("DELETE FROM settings WHERE key = ?", (key,))
            else:
                await self._db.execute(
                    "INSERT INTO settings (key, value) VALUES (?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, value),
                )
            await self._db.commit()

    async def get_setting(self, key: str) -> str | None:
        row = await self._fetchone("SELECT value FROM settings WHERE key = ?", (key,))
        return row["value"] if row else None

    async def get_settings(self, prefix: str = "") -> dict:
        if prefix:
            rows = await self._fetchall(
                "SELECT key, value FROM settings WHERE key LIKE ?", (prefix + "%",)
            )
        else:
            rows = await self._fetchall("SELECT key, value FROM settings")
        return {r["key"]: r["value"] for r in rows}

    # ------------------------------------------------------------------ ad views
    async def register_ad_view(self, user_id: int) -> None:
        now = utcnow_iso()
        async with self._lock:
            await self._db.execute(
                "INSERT INTO ad_views (user_id, views, last_view) VALUES (?, 1, ?) "
                "ON CONFLICT(user_id) DO UPDATE SET views = views + 1, last_view = excluded.last_view",
                (user_id, now),
            )
            await self._db.commit()

    async def ad_stats(self) -> tuple[int, int]:
        row = await self._fetchone("SELECT COALESCE(SUM(views), 0) AS s, COUNT(*) AS c FROM ad_views")
        if not row:
            return 0, 0
        return row["s"], row["c"]

    # ------------------------------------------------------------------ helpers
    async def _fetchone(self, query: str, params: tuple = ()):
        cur = await self._db.execute(query, params)
        row = await cur.fetchone()
        await cur.close()
        return row

    async def _fetchall(self, query: str, params: tuple = ()) -> list:
        cur = await self._db.execute(query, params)
        rows = await cur.fetchall()
        await cur.close()
        return rows

    async def get_matches_by_ids(self, ids: list[int]) -> list:
        if not ids:
            return []
        placeholders = ",".join("?" for _ in ids)
        rows = await self._fetchall(
            f"SELECT * FROM matches WHERE id IN ({placeholders})", tuple(ids)
        )
        by_id = {r["id"]: r for r in rows}
        return [by_id[i] for i in ids if i in by_id]
